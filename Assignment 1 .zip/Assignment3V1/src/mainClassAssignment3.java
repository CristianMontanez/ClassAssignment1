import java.io.File;
import java.io.IOException;

import javax.swing.*;
public class mainClassAssignment3 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		BasicFile f ; 
		
		f= new BasicFile(); // creates pop up file directory from the constructor of basicfile 
		
		boolean menuStatus = false ;			
		
		String menu ="Please enter one of the following options \n (1). Open File Directory \n (2). Copy file \n (3) Append or overwrite a file \n (4). Get file Details \n (5). Display contents of file\n (6).Close program";

		
		while (!menuStatus)  // keeps program running untill menuStatus varible is TRUE; 
		{
			
			String optionScreen = JOptionPane.showInputDialog(menu); // JOptionPane menu for specifc actions for slected file.
			
			
			int menuChooser = Integer.parseInt(optionScreen);
			
			
			switch(menuChooser) {
			case 1 :
			
				f = new BasicFile();
				break;
		
			case 2 : 
				
				f.copyFile();
				break;
				
			case 3 :
				
				// sub menu to select whether user wants to append the text file or overwrite it. 
				int submenu = getDataV1.getInt("Please select one of the following opitions \n (1). Append text to the existing file \n (2). Overwrite the text on existing file");
		
                  switch (submenu) {
				// method to append text to file 
				case 1 : 
					f.appendFile();
					break;
					// method to overwrite the text to file
				case 2 : 
					f.overwriteFile();
					break;
                  }
			
				break;
				
			case 4 : 
				
				f.getFileDetails();
				
				break;
		
			case 5 : 
				f.displayContents();
				break;
				
				
			case 6 : 
				
				menuStatus = true; 
				break;
			}
		
			
			
			
			}
		
		
		}
		
		

	
	
	  static void display(String msg, String s, int t)
	  {
		  JOptionPane.showMessageDialog(null, msg, s, t);
	  }
	  
	  static void display2(String msg, String s, int t)
	  {
		    JTextArea text = new JTextArea(s, 20, 30);
	        JScrollPane pane = new  JScrollPane(text);
	        JOptionPane.showMessageDialog(null, pane, s, t);
	  }

	  
	  static void display(BasicFile f ) 
	  {
		  String s = f.getName();
		  
		  display (f.getName(), "File Chosen " , JOptionPane.INFORMATION_MESSAGE);
	  }

}
