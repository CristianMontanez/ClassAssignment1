import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


//Cristian Montanez
//Assignment 3 
// October 23 2022 
// Professor Smith
public class BasicFile {

  File f ;
  String filePath ; 
  
  BasicFile()
  {
	  JFileChooser chooser  = new JFileChooser (); 
	  int selectionStatus = chooser.showOpenDialog(null);
	  
	  try 
	  {
		  if (selectionStatus != chooser.APPROVE_OPTION) throw new IOException ();
		  
		  f = chooser.getSelectedFile();
		
		  
		  display(f.getName(), "is the selected file" , JOptionPane.INFORMATION_MESSAGE );
		  
	  }
	  
	  catch(IOException e ) 
	  {
		  display(null, "Operation selcted not available ", JOptionPane.ERROR_MESSAGE);
	  }
  }
  
  public String getName() 
  {
	  return f.getName();
  }
  
  public String filePath () 
  {
	  return f.getPath();
  }

	  
  public void copyFile () throws IOException
  
  {
	  
	
	File of = new File(f.getPath());
	File cf = new File("/Users/splashysplash/Documents/CopyFile");
	  
	  FileInputStream source  = null;
	  FileOutputStream output = null;
	  
		source = new FileInputStream(of);
		output= new FileOutputStream(cf);
	
	   byte [] buffer = new byte [1024]; 
	   int length ; 
	  
		try {
			while ((length = source.read(buffer)) > 0)
			   {
				   output.write(buffer, 0 , length);
			   }
			display(cf.getName() , "a copy of the file was created ", JOptionPane.INFORMATION_MESSAGE);
		
		} 
		
		finally {
			source.close();
			output.close();
		}
	
	
		 
	   
  }
  
 	
  
	   
  public  void appendFile() 
  {
	  String S = getDataV1.getString("Please enter the text you wish to append") ;
	  
	  
	  
  
  	try {
			FileWriter fw = new FileWriter (f.getAbsoluteFile() , true );
			
			fw.write("\n" + S);
			fw.close();
			display(f.getName() , "text has been appended to this file ", JOptionPane.INFORMATION_MESSAGE);
	
			
		} catch (IOException e) {
			System.out.println("Error has occured with desired operation");
		}
  }
  
  public  void overwriteFile() 
  {
	  String S = getDataV1.getString("Please enter the text you to overwrite the selected file with") ;
	  
	  
	  
  
  	try {
			FileWriter fw = new FileWriter (f.getAbsoluteFile() , false );
			
			fw.write("\n" + S);
			fw.close();
			display(f.getName() , "File has been overwritten ", JOptionPane.INFORMATION_MESSAGE);
	
			
		} catch (IOException e) {
			System.out.println("Error has occured with desired operation");
		}
  }
  
  
  public void getFileDetails() throws IOException 
  {
	  
	  double kbSize = f.length() / 1024;
	  
	  String str = "File path: \t " + f.getAbsolutePath() + "\n Size of file in KB: \t" + kbSize +  "\n Number of lines : \t" + fileLineReader();
	  display2("File Contents", str   , JOptionPane.INFORMATION_MESSAGE);
  }
  
 public long fileLineReader ()throws 
IOException
 {
	 
	 File of = new File(f.getPath());
	 long lineReader = 0 ; 
	 
	 LineNumberReader lnr = new LineNumberReader (new FileReader (of));
	 
	 while(lnr.readLine()!=null);
	lineReader = lnr.getLineNumber();
		 
	 
	 return lineReader;
 }
 
 public void displayContents() throws IOException
 {
	 BufferedReader br = new BufferedReader (new FileReader (f.getName()));
	 
	 String output;
	 
	 while ((output = br.readLine() )!= null) {
	 
	 	 display2(null , output, JOptionPane.INFORMATION_MESSAGE);
	 	 
	 	 

	 }
	 
	 
 }
 
 
  static void display(String msg, String s, int t)
  {
	  JOptionPane.showMessageDialog(null, msg, s, t);
  }
  
  
  
  static void display2(String msg, String s, int t)
  {
	    JTextArea text = new JTextArea(s, 20, 30);
        JScrollPane pane = new  JScrollPane(text);
        JOptionPane.showMessageDialog(null, pane, s, t);
  }
	
}
